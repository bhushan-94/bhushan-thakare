function  readHere(){
    let username = document.querySelector("#user");
    user.innerHTML = username;

    var username = document.querySelector(".textbox").value
}
 fuction Comment() {
     let text = document.querySelector("#pasw");
     pasw.innerHTML text;

     var username = document.querySelector(".textbox").value
}
fuction read() {
    let text2 = document.querySelector("#read");
    read.innerHTML text2;

    var username = document.querySelector(".textbox").value
}
